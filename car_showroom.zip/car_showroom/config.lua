Config = {}

Config.GarageName = 'Central Garage' -- The garage where bought cars will be stored (must match your garage script)
Config.StoredState = 1 -- 1 = Stored (in garage), 0 = Out. set to 1 so they can pull it out from garage? Or 0 if it spawns in front of them? 
-- User wanted it spawned "at delivery point", so it is "Out" (0).

Config.ShowroomCars = {
    { model = '765lt', price = 250000, coords = vector4(-1256.94, -366.31, 36.18, 83.10), zOffset = 0.0 },
    { model = '2015autobio', price = 150000, coords = vector4(-1262.83, -353.76, 36.18, 39.72), zOffset = 0.0 },
    { model = '22g63', price = 200000, coords = vector4(-1269.22, -363.61, 36.18, 92.38), zOffset = 0.0 },
    { model = '19sclass', price = 120000, coords = vector4(-1244.23, -356.63, 40.09, 89.15), zOffset = 0.0 },
    { model = 'rev', price = 500000, coords = vector4(-1247.05, -351.81, 40.07, 81.42), zOffset = 0.0 }
}


Config.TestDriveCoords = vector4(-1241.98, -392.60, 36.80, 28.77)
Config.DeliveryCoords = vector4(-1245.51, -394.78, 36.80, 27.77)

Config.Blip = {
    Coords = vector3(-1264.9885, -367.0415, 36.6611),
    Sprite = 225,
    Display = 4,
    Scale = 1.0,
    Colour = 3,
    Name = "Premium Car Dealership"
}
