
-- Note: ESX is imported via @es_extended/imports.lua in fxmanifest shared_scripts
-- Config is available globally

-- Spawning Showroom Vehicles
CreateThread(function()
    for _, car in ipairs(Config.ShowroomCars) do
        local carModel = GetHashKey(car.model)
        
        RequestModel(carModel)
        while not HasModelLoaded(carModel) do
            Wait(10)
        end

        local finalZ = car.coords.z - (car.zOffset or 0.0)
        local vehicle = CreateVehicle(carModel, car.coords.x, car.coords.y, finalZ, car.coords.w, false, false)
        
        SetEntityAsMissionEntity(vehicle, true, true)
        SetVehicleDoorsLocked(vehicle, 2)
        SetEntityInvincible(vehicle, true)
        FreezeEntityPosition(vehicle, true)
        SetModelAsNoLongerNeeded(carModel)

        exports.ox_target:addLocalEntity(vehicle, {
            {
                name = 'test_drive_' .. car.model,
                icon = 'fa-solid fa-car',
                label = 'Test Drive',
                onSelect = function()
                    StartTestDrive(car.model)
                end
            },
            {
                name = 'buy_car_' .. car.model,
                icon = 'fa-solid fa-money-bill',
                label = 'Buy Vehicle ($' .. car.price .. ')',
                onSelect = function()
                    -- Request Purchase (Step 1)
                    TriggerServerEvent('car_showroom:requestPurchase', car.model)
                end
            }
        })
    end
end)

-- Test Drive Logic
function StartTestDrive(model)
    local coords = Config.TestDriveCoords
    if ESX.Game.IsSpawnPointClear(coords, 3.0) then
        ESX.Game.SpawnVehicle(model, coords, coords.w, function(vehicle)
            SetVehicleNumberPlateText(vehicle, "TESTDRIVE")
            TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
            ClearPedTasks(PlayerPedId()) -- Clean warp task if needed
            
            local blip = AddBlipForEntity(vehicle)
            SetBlipSprite(blip, 225)
            SetBlipColour(blip, 2)
            SetBlipScale(blip, 0.8)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Test Drive: " .. model)
            EndTextCommandSetBlipName(blip)
            
            lib.notify({
                title = 'Test Drive Ready',
                description = 'Your ' .. model .. ' is available for test drive!',
                type = 'success',
                icon = 'car',
                position = 'top'
            })
            
             CreateThread(function()
                while DoesEntityExist(vehicle) do
                    Wait(1000)
                    if IsPedInVehicle(PlayerPedId(), vehicle, false) then
                        RemoveBlip(blip)
                        break
                    end
                end
            end)
        end)
    else
        lib.notify({
            title = 'Unavailable',
            description = 'Test drive spot is blocked!',
            type = 'error'
        })
    end
end

-- Purchase FLOW - Step 2: Authorize & Spawn
RegisterNetEvent('car_showroom:authorizePurchase', function(model, plate)
    local coords = Config.DeliveryCoords
    
    if ESX.Game.IsSpawnPointClear(coords, 3.0) then
        ESX.Game.SpawnVehicle(model, coords, coords.w, function(vehicle)
             -- Use Game.SpawnVehicle callback to ensure entity exists
            SetVehicleNumberPlateText(vehicle, plate)
            SetVehicleDoorsLocked(vehicle, 1)
            
            -- Get Props to save to DB
            local props = ESX.Game.GetVehicleProperties(vehicle)
            
            -- Send back to finalizer (Step 3)
            TriggerServerEvent('car_showroom:finalizePurchase', props)
            
            -- Add Blip for user
            local blip = AddBlipForEntity(vehicle)
            SetBlipSprite(blip, 225)
            SetBlipColour(blip, 3) 
            SetBlipScale(blip, 0.8)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Purchased: " .. model)
            EndTextCommandSetBlipName(blip)
            
             CreateThread(function()
                while DoesEntityExist(vehicle) do
                    Wait(1000)
                    if IsPedInVehicle(PlayerPedId(), vehicle, false) then
                        RemoveBlip(blip)
                        break
                    end
                end
            end)
        end)
    else
        lib.notify({
            title = 'Delivery Error',
            description = 'Delivery point blocked! Money was not taken. Please clear the area.',
            type = 'error'
        })
    end
end)

-- Debug Command
RegisterCommand('getcarpos', function()
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then
        local vehicle = GetVehiclePedIsIn(ped, false)
        local coords = GetEntityCoords(vehicle)
        local heading = GetEntityHeading(vehicle)
        print(string.format('vector4(%s, %s, %s, %s)', coords.x, coords.y, coords.z, heading))
    end
end, false)

-- Create Map Blip
CreateThread(function()
    local blip = AddBlipForCoord(Config.Blip.Coords)

    SetBlipSprite (blip, Config.Blip.Sprite)
    SetBlipDisplay(blip, Config.Blip.Display)
    SetBlipScale  (blip, Config.Blip.Scale)
    SetBlipColour (blip, Config.Blip.Colour)
    SetBlipAsShortRange(blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.Blip.Name)
    EndTextCommandSetBlipName(blip)
end)
