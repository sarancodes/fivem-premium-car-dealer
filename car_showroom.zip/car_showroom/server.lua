
local pendingPurchases = {}
math.randomseed(os.time())

-- Debug Helper
local function DebugLog(msg)
    print('^3[car_showroom] [DEBUG v2] ' .. msg .. '^0')
end

RegisterNetEvent('car_showroom:requestPurchase', function(model)
    local _source = source
    DebugLog('RequestPurchase received from ID: ' .. _source .. ' for model: ' .. model)
    
    local xPlayer = ESX.GetPlayerFromId(_source)
    if not xPlayer then 
        DebugLog('ERROR: xPlayer is nil for source ' .. _source)
        return 
    end

    local price = nil
    for _, car in ipairs(Config.ShowroomCars) do
        if car.model == model then
            price = car.price
            break
        end
    end

    if not price then 
        DebugLog('Invalid model requested: ' .. model)
        return 
    end

    if xPlayer.getMoney() >= price then
        local plate = string.upper(ESX.GetRandomString(3) .. ' ' .. math.random(100, 999))
        
        pendingPurchases[_source] = {
            model = model,
            price = price,
            plate = plate
        }
        
        DebugLog('Authorized. Waiting for client spawn. Plate: ' .. plate)
        TriggerClientEvent('car_showroom:authorizePurchase', _source, model, plate)
    else
        TriggerClientEvent('ox_lib:notify', _source, {
            title = 'Purchase Failed',
            description = 'You need $' .. price,
            type = 'error'
        })
    end
end)

RegisterNetEvent('car_showroom:finalizePurchase', function(netProps)
    local _source = source
    DebugLog('FinalizePurchase received from ID: ' .. _source)
    
    local xPlayer = ESX.GetPlayerFromId(_source)
    if not xPlayer then 
        DebugLog('ERROR: xPlayer is nil in finalize for source ' .. _source)
        return 
    end

    local purchaseData = pendingPurchases[_source]
    if not purchaseData then 
        DebugLog('ERROR: No pending purchase found inside finalize. Valid for 10s?')
        -- Maybe log what IS there?
        return 
    end

    if xPlayer.getMoney() >= purchaseData.price then
        xPlayer.removeMoney(purchaseData.price)
        DebugLog('Funds deducted (v2).')
        
        local vehicleProps = netProps
        vehicleProps.plate = purchaseData.plate
        
        local jsonProps = json.encode(vehicleProps)
        
        -- Using DIRECT export to bypass missing MySQL global
        DebugLog('Attempting DB Insert via exports.oxmysql:insert...')
        
        local success = pcall(function()
            exports.oxmysql:insert('INSERT INTO owned_vehicles (owner, plate, vehicle, type, stored) VALUES (?, ?, ?, ?, ?)', {
                xPlayer.identifier,
                purchaseData.plate,
                jsonProps,
                'car',
                0
            }, function(id)
                if id then
                    DebugLog('DB Insert SUCCESS. ID: ' .. id)
                    TriggerClientEvent('ox_lib:notify', _source, {
                        title = 'Purchase Successful',
                        description = 'Vehicle purchased and is available at delivery point!',
                        type = 'success'
                    })
                else
                    DebugLog('DB Insert RETURNED NIL/FALSE.')
                    -- Attempt Refund
                    xPlayer.addMoney(purchaseData.price)
                    TriggerClientEvent('ox_lib:notify', _source, {
                        title = 'Error',
                        description = 'Database Error. Money Refunded.',
                        type = 'error'
                    })
                end
            end)
        end)
        
        if not success then
             DebugLog('CRITICAL ERROR: exports.oxmysql call crashed!')
             xPlayer.addMoney(purchaseData.price)
        end
        
        pendingPurchases[_source] = nil
    else
        DebugLog('Player cannot afford at finalize step.')
    end
end)
